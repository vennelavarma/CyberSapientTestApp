//
//  AccentColorViewModel.swift
//  CyberSapientTestApp
//
//  Created by vennela atcha on 2/25/25.
//

import Foundation
import SwiftUI

class AccentColorViewModel: ObservableObject {
    @AppStorage("accentColor") var selectedColor: String = "blue"
    
    let availableColors: [String: Color] = [
        "blue": .blue, "green": .green, "red": .red,
        "orange": .orange, "purple": .purple
    ]
    
    func getSelectedColor() -> Color {
        availableColors[selectedColor] ?? .blue
    }
}
