//
//  TaskViewModel.swift
//  CyberSapientTestApp
//
//  Created by vennela atcha on 2/25/25.
//

import Foundation
import CoreData

class TaskViewModel: ObservableObject {
    
    @Published var tasks: [Item] = []
    @Published var sortOption: SortOption = .dueDate
    @Published var filterStatus: TaskStatus = .all
    
    let container: NSPersistentContainer
    
    init() {
        container = NSPersistentContainer(name: "CyberSapientTestApp")
        container.loadPersistentStores { _, error in
            if let error = error {
                print("Error loading Core Data: \(error)")
            }
        }
        fetchTasks()
    }
    
    func fetchTasks() {
        let request: NSFetchRequest<Item> = Item.fetchRequest()
        
        switch sortOption {
                case .title:
                    request.sortDescriptors = [NSSortDescriptor(keyPath: \Item.taskTitle, ascending: true)]
                case .priority:
                    request.sortDescriptors = [NSSortDescriptor(keyPath: \Item.taskPriority, ascending: false)]
                case .dueDate:
                    request.sortDescriptors = [NSSortDescriptor(keyPath: \Item.dueDate, ascending: true)]
                }
        
        switch filterStatus {
                case .completed:
                    request.predicate = NSPredicate(format: "isTaskCompleted == %@", NSNumber(value: true))
                case .pending:
                    request.predicate = NSPredicate(format: "isTaskCompleted == %@", NSNumber(value: false))
                case .all:
                    break // No filtering
                }
        
        do {
            tasks = try container.viewContext.fetch(request)
        } catch {
            print("Error fetching tasks: \(error)")
        }
    }
    
    func addTask(title: String, desc: String?, priority: String, dueDate: Date) {
        let newTask = Item(context: container.viewContext)
        newTask.taskTitle = title
        newTask.taskDescription = desc
        newTask.taskDescription = priority
        newTask.dueDate = dueDate
        newTask.isTaskCompleted = false
        
        saveContext()
    }
    
    func deleteTask(task: Item) {
        container.viewContext.delete(task)
        saveContext()
    }
    
    func saveContext() {
        do {
            try container.viewContext.save()
            fetchTasks()
        } catch {
            print("Error saving Core Data: \(error)")
        }
    }
    
    func changeSortOption(_ newSort: SortOption) {
            sortOption = newSort
            fetchTasks() // Refresh list
    }
    
    func changeFilterStatus(_ newStatus: TaskStatus) {
            filterStatus = newStatus
            fetchTasks() // Refresh tasks when filter changes
    }
}


enum SortOption: String, CaseIterable {
    case title = "Alphabetically"
    case priority = "By Priority"
    case dueDate = "By Due Date"
}

enum TaskStatus: String, CaseIterable {
    case all = "All"
    case completed = "Completed"
    case pending = "Pending"
}

