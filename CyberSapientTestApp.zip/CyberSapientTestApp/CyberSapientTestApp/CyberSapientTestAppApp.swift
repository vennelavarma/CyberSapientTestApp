//
//  CyberSapientTestAppApp.swift
//  CyberSapientTestApp
//
//  Created by vennela atcha on 2/25/25.
//

import SwiftUI

@main
struct CyberSapientTestAppApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            TaskManagerView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
