//
//  TaskCreationView.swift
//  CyberSapientTestApp
//
//  Created by vennela atcha on 2/25/25.
//

import SwiftUI

struct TaskCreationView: View {
    
    @Environment(\.dismiss) var dismiss
    @ObservedObject var viewModel: TaskViewModel
    @State private var title = ""
    @State private var desc = ""
    @State private var priority = "Medium"
    @State private var dueDate = Date()
    let priorities = ["Low", "Medium", "High"]

    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Create A Task")) {
                    TextField("Title", text: $title)
                        .autocapitalization(.words)
                        .accessibilityLabel("Enter task title")
                        .accessibilityHint("Required field, enter the title of the task.")
                        .accessibilityAddTraits(.isStaticText)
                    
                    TextField("Description", text: $desc)
                        .accessibilityLabel("Enter task description")
                        .accessibilityAddTraits(.isStaticText)
                        .accessibilityHint("Optional field, provide a description of the task.")
                    
                    Picker("Priority", selection: $priority) {
                        ForEach(priorities, id: \.self) {
                            Text($0)
                                .accessibilityLabel("Selected Task Priority: \($0)")
                                .accessibilityHint("Selected the priority for the task.")
                                .accessibilityAddTraits(.isSelected)
                        }
                    }.accessibilityLabel("Select Task Priority")
                        .accessibilityHint("Choose the priority for the task.")
                        .accessibilityAddTraits(.isStaticText)
                    
                    DatePicker("Due Date", selection: $dueDate, displayedComponents: .date)
                        .accessibilityLabel("Select Task Due Date")
                        .accessibilityAddTraits(.isSelected)
                        .accessibilityHint("Pick a date for the task to be completed.")
                }.accessibilityLabel("Task Details Header")
                    .accessibilityAddTraits(.isHeader)
                
                Section {
                    Button("Save Task") {
                        if !title.isEmpty {
                            withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
                                viewModel.addTask(title: title, desc: desc, priority: priority, dueDate: dueDate)
                            }
                            dismiss()
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(title.isEmpty)
                    .accessibilityLabel("Save Task Button")
                    .accessibilityHint("Tap to save the task")
                    .accessibilityAddTraits(.isButton)
                }
            }
            .navigationTitle("Add Task")
            .accessibilityLabel("Add Task Navigation Title")
            .accessibilityAddTraits(.isHeader)
            .accessibilityElement(children: .combine)
        }
    }
}

#Preview {
    TaskCreationView(viewModel: TaskViewModel())
}
