//
//  EmptyStateView.swift
//  CyberSapientTestApp
//
//  Created by vennela atcha on 2/25/25.
//

import SwiftUI

struct EmptyStateView: View {
    var message: String
    var systemImage: String
    var action: (() -> Void)? // Optional button action

    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: systemImage)
                .font(.system(size: 80))
                .foregroundColor(.gray)
                .accessibilityHidden(true) // Hides from VoiceOver to avoid redundancy
            
            Text("Nothing here yet!")
                .font(.title)
                .fontWeight(.semibold)
                .foregroundColor(.primary)
                .accessibilityLabel("No tasks available")

            Text(message)
                .font(.body)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 30)
                .accessibilityHint("Add a new task to get started")

            if let action = action {
                Button(action: action) {
                    Label("Add New Task", systemImage: "plus.circle.fill")
                        .font(.title2)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .shadow(radius: 5)
                }
                .accessibilityLabel("Add new task button")
                .accessibilityHint("Tap to create a new task")
            }
        }
        .padding()
        .accessibilityElement(children: .combine)
    }
}

#Preview {
    EmptyStateView(message: "", systemImage: "")
}
