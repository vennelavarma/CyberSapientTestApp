//
//  TaskRowView.swift
//  CyberSapientTestApp
//
//  Created by vennela atcha on 2/25/25.
//

import SwiftUI

struct TaskRowView: View {
    
    let task: Item
    @State private var appear = false // State for fade-in animation
    @State private var scale = 0.9 // State for scale animation
    @State private var animateCompletion = false // State for completion animation
    
    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text(task.taskTitle ?? "")
                    .font(.headline)
                    .scaleEffect(appear ? 1 : scale) // Apply scale effect
                    .opacity(appear ? 1 : 0) // Fade-in effect
                    .onAppear {
                        withAnimation(.easeOut(duration: 0.8)) {
                            appear = true
                        }
                        withAnimation(.easeIn(duration: 1.0).delay(0.2)) {
                            scale = 1
                        }
                    }
                    .accessibilityLabel("Task title, \(String(describing: task.taskTitle))")
                    .accessibilityAddTraits(.isStaticText)
                    .accessibilityHint("This is the title of the task.")
                
                Text(task.taskPriority ?? "")
                    .font(.subheadline)
                    .foregroundColor(priorityColor(priority: task.taskPriority ?? ""))
                    .opacity(appear ? 1 : 0)
                    .onAppear {
                        withAnimation(.easeOut(duration: 0.8).delay(0.2)) {
                            appear = true
                        }
                    }
                    .accessibilityLabel("Task priority, \(String(describing: task.taskPriority))")
                    .accessibilityAddTraits(.isStaticText)
                    .accessibilityHint("Indicates the priority level of the task.")
                
                Text("Due: \(task.dueDate ?? Date(), style: .date)")
                    .font(.caption)
                    .foregroundColor(.gray)
                    .opacity(appear ? 1 : 0)
                    .offset(x: appear ? 0 : 100) // Slide-in effect
                    .onAppear {
                        withAnimation(.easeOut(duration: 0.8).delay(0.4)) {
                            appear = true
                        }
                    }
                    .accessibilityLabel("Due date, \(String(describing: task.dueDate?.formatted(date: .abbreviated, time: .omitted)))")
                    .accessibilityAddTraits(.isStaticText)
                    .accessibilityHint("Shows when the task is due.")
            }
            Spacer()
            if task.isTaskCompleted {
                Image(systemName: task.isTaskCompleted ? "checkmark.circle.fill" : "circle")
                    .foregroundColor(task.isTaskCompleted ? .green : .gray)
                    .scaleEffect(animateCompletion ? 1.2 : 1) // Scale effect when task is completed
                    .rotationEffect(animateCompletion ? .degrees(360) : .degrees(0)) // Bounce effect on complete
                    .onAppear {
                        withAnimation(.spring(response: 0.5, dampingFraction: 0.7, blendDuration: 0.7)) {
                            animateCompletion.toggle()
                        }
                    }
                    .accessibilityLabel(task.isTaskCompleted ? "Task Completed" : "Task Pending")
                    .accessibilityAddTraits(.isImage)
                    .accessibilityHint(task.isTaskCompleted ? "This task has been completed." : "This task is still pending.")
            }
        }
        .padding(.vertical, 5)
        .accessibilityElement(children: .combine)
        .accessibilityHint("Double-tap to open task details")
    }
    
    public func priorityColor(priority: String) -> Color {
        switch priority {
        case "High": return .red
        case "Medium": return .orange
        default: return .green
        }
    }
}

#Preview {
    TaskRowView(task: Item.init())
}
