//
//  AboutView.swift
//  CyberSapientTestApp
//
//  Created by uma atcha on 2/25/25.
//

import SwiftUI

struct AboutView: View {
    var body: some View {
        VStack(spacing: 10) {
            Text("Task Manager App")
                .font(.largeTitle)
                .bold()
                .accessibilityLabel("Task Manager App")
                .accessibilityHint("This is the app's name")

            Text("Version 1.0.0")
                .foregroundColor(.secondary)
                .accessibilityLabel("Version 1.0.0")
                .accessibilityHint("This is the current version of the app")

            Text("Built with ❤️ using SwiftUI 5")
                .padding()
                .accessibilityLabel("Built with love using SwiftUI 5")
                .accessibilityHint("This app was developed using SwiftUI version 5")

            Spacer()
        }
        .navigationTitle("About")
        .accessibilityElement(children: .combine)
    }
}

#Preview {
    AboutView()
}
