//
//  SettingsView.swift
//  CyberSapientTestApp
//
//  Created by vennela atcha on 2/25/25.
//

import SwiftUI

struct SettingsView: View {
    
    // Theme Settings
    @AppStorage("isDarkMode") private var isDarkMode = false
    // Notification Settings
    @AppStorage("enableNotifications") private var enableNotifications = true
    // Accessibility Settings
    @State private var textSize: Double = 14
    @StateObject private var accentColorViewModel = AccentColorViewModel()
    

    var body: some View {
        NavigationStack {
            Form {
                // MARK: - Appearance 
                Section(header: Text("APPEARANCE")) {
                    Toggle("Dark Mode", isOn: $isDarkMode)
                        .onChange(of: isDarkMode) { _ in
                            UIApplication.shared.windows.first?.overrideUserInterfaceStyle = isDarkMode ? .dark : .light
                        }.accessibilityLabel("Enable Dark Mode")
                        .accessibilityValue(isDarkMode ? "On" : "Off")
                        .accessibilityHint("Switch between dark and light mode for the app interface.")
                    
                    
                    
                }
                Section(header: Text("Accent Color Settings")) {
                    Picker("Accent Color", selection: $accentColorViewModel.selectedColor) {
                        ForEach(accentColorViewModel.availableColors.keys.sorted(), id: \.self) { color in
                            Text(color.capitalized).tag(color).accessibilityLabel("\(color.capitalized) Color") // Ensures clear pronunciation
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .accessibilityLabel("Accent Color")
                    .accessibilityValue(accentColorViewModel.selectedColor.capitalized) // Announces selected color
                    .accessibilityHint("Double tap to choose a different accent color")
                }
                // MARK: - Enable And Disable Notifications
                Section(header: Text("NOTIFICATIONS")) {
                    Toggle("Enable Notifications", isOn: $enableNotifications)
                        .accessibilityLabel("Enable Notifications")
                        .accessibilityValue(enableNotifications ? "Enabled" : "Disabled")
                        .accessibilityHint("Turn on/off notifications for the app.")
                }
                
                // MARK: - Accessibility For Preview Text
                Section(header: Text("ACCESSIBILITY")) {
                    Slider(value: $textSize, in: 12...24, step: 1)
                        .accentColor(accentColorViewModel.getSelectedColor())
                        .accessibilityLabel("Text Size")
                        .accessibilityValue("\(Int(textSize)) points")
                        .accessibilityHint("Adjust the font size for better readability.")
                    
                    Text("Preview Text")
                        .font(.system(size: textSize))
                        .foregroundColor(.secondary)
                        .accessibilityLabel("Preview Text")
                        .accessibilityValue("Text Size: \(Int(textSize))")
                        .accessibilityHint("Preview how the text looks with the current size setting.")
                    
                }
                // MARK: - About View
                Section {
                    NavigationLink("About This App") {
                        AboutView()
                    }.accessibilityLabel("About This App")
                        .accessibilityHint("Tap to learn more about the app and its features.")
                }
                .accessibilityElement(children: .combine)
                .navigationTitle("Settings")
            }
        }
    }
}

#Preview {
    SettingsView()
}
