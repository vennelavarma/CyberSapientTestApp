//
//  ShimmerView.swift
//  CyberSapientTestApp
//
//  Created by vennela atcha on 2/27/25.
//

import SwiftUI

struct ShimmerView: View {
    @State private var move = false
    
    let gradient = LinearGradient(
        gradient: Gradient(colors: [Color.gray.opacity(0.2), Color.gray.opacity(0.4), Color.gray.opacity(0.2)]),
        startPoint: .leading,
        endPoint: .trailing
    )
    
    var body: some View {
        Rectangle()
            .fill(gradient)
            .cornerRadius(8)
            .frame(height: 20)
            .padding(.vertical, 5)
            .modifier(ShimmerAnimation(move: $move))
            .onAppear {
                withAnimation(Animation.linear(duration: 1.5).repeatForever(autoreverses: false)) {
                    self.move.toggle()
                }
            }
    }
}

struct ShimmerAnimation: ViewModifier {
    @Binding var move: Bool
    
    func body(content: Content) -> some View {
        content
            .mask(
                Rectangle()
                    .fill(LinearGradient(gradient: Gradient(colors: [Color.white, Color.black.opacity(0.2), Color.white]),
                                         startPoint: .leading, endPoint: .trailing))
                    .rotationEffect(.degrees(70))
                    .offset(x: move ? 200 : -200)
                    .animation(.linear(duration: 1.5).repeatForever(autoreverses: false))
            )
    }
}


#Preview {
    ShimmerView()
}
