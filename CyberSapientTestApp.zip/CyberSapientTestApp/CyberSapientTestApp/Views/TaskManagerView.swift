//
//  TaskManagerView.swift
//  CyberSapientTestApp
//
//  Created by vennela atcha on 2/28/25.
//

import SwiftUI

struct TaskManagerView: View {
    var body: some View {
        NavigationStack {
            VStack {
                Text("Welcome to Task Manager")
                    .font(.title)
                    .padding()

                NavigationLink(destination: TaskListView()) {
                    Text("Go to Task List")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .shadow(radius: 5)
                }
                .padding()
            }
            .navigationTitle("Task Manager")
        }
    }
}

#Preview {
    TaskManagerView()
}
