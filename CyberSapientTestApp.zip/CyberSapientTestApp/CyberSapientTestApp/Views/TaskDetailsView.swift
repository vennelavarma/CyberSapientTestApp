//
//  TaskDetailsView.swift
//  CyberSapientTestApp
//
//  Created by vennela atcha on 2/25/25.
//

import SwiftUI

struct TaskDetailsView: View {
    
    let task: Item
    @ObservedObject var viewModel: TaskViewModel
    @State private var appear = false // State for fade-in animation
    @State private var scale = 0.9 // State for scale animation
    @State private var animateCompletion = false // State for completion animation
    
    var body: some View {
        VStack(spacing: 20) {
            Text(task.taskTitle ?? "")
                .font(.title)
                .bold()
                .scaleEffect(appear ? 1 : scale) // Applying scale animation
                .opacity(appear ? 1 : 0) // Fade-in effect
                .onAppear {
                    withAnimation(.easeOut(duration: 0.8)) {
                        appear = true
                    }
                    withAnimation(.easeIn(duration: 1.0).delay(0.2)) {
                        scale = 1
                    }
                }
                .accessibilityLabel(task.taskTitle ?? "")
                .accessibilityHint("Displayed task name")
                .accessibilityAddTraits(.isStaticText)
            
            Text(task.taskDescription ?? "No description")
                .font(.body)
                .foregroundColor(.gray)
                .opacity(appear ? 1 : 0) // Fade-in effect
                .onAppear {
                    withAnimation(.easeOut(duration: 0.8).delay(0.2)) {
                        appear = true
                    }
                }
                .accessibilityLabel(task.taskDescription ?? "")
                .accessibilityHint("Displayed task description")
                .accessibilityAddTraits(.isStaticText)
            
            Text("Due: \(task.dueDate ?? Date(), style: .date)")
                .font(.subheadline)
                .foregroundColor(.blue)
                .opacity(appear ? 1 : 0)
                .offset(x: appear ? 0 : 100) // Slide from the right
                .onAppear {
                    withAnimation(.easeOut(duration: 0.8).delay(0.4)) {
                        appear = true
                    }
                }
                .accessibilityLabel("Due date, \(String(describing: task.dueDate?.formatted(date: .abbreviated, time: .omitted)))")
                .accessibilityHint("Displayed task date")
                .accessibilityAddTraits(.isStaticText)
            
            Toggle("Mark as Completed", isOn: Binding(
                get: { task.isTaskCompleted },
                set: { newValue in
                    task.isTaskCompleted = newValue
                    viewModel.saveContext()
                }
            ))
            .toggleStyle(SwitchToggleStyle(tint: .green))
            .accessibilityLabel(task.isTaskCompleted ? "Task Completed" : "Task Pending")
            .accessibilityHint("Displays the task completed or pending")
            .accessibilityAddTraits(.isToggle)

            Spacer()
        }
        .padding()
        .navigationTitle("Task Details")
        .accessibilityLabel("Navigation Title is Task Details")
        .accessibilityAddTraits(.isHeader)
        .accessibilityElement(children: .combine)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Delete", role: .destructive) {
                    viewModel.deleteTask(task: task)
                }
                .accessibilityLabel("Delete Button Tapped")
                .accessibilityAddTraits(.isButton)
            }
        }
    }
}

#Preview {
    TaskDetailsView(task: Item.init(), viewModel: TaskViewModel())
}
