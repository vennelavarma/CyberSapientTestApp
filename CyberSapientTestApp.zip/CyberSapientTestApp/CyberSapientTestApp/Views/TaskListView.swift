//
//  TaskListView.swift
//  CyberSapientTestApp
//
//  Created by vennela atcha on 2/25/25.
//

import SwiftUI

struct TaskListView: View {
    
    @StateObject var viewModel = TaskViewModel()
    @State private var showAddTask = false
    @ObservedObject var accentColorVM = AccentColorViewModel()
    
    var body: some View {
        NavigationStack {
            VStack {
                // Task List
                if viewModel.tasks.isEmpty {
                    EmptyStateView(message: "No Tasks Yet!", systemImage: "tray.full.fill")
                            .accessibilityLabel("Empty State View")
                            .accessibilityAddTraits(.isStaticText)
                } else {
                    
                    // Sorting Picker
                    Picker("Sort by", selection: $viewModel.sortOption) {
                        ForEach(SortOption.allCases, id: \.self) { option in
                            Text(option.rawValue).tag(option)
                                .accessibilityLabel(option.rawValue)
                                .accessibilityAddTraits(.isSelected)
                                .accessibilityHint("Sort tasks by Due Date, Priority, or Alphabetically")

                        }
                    }
                    .pickerStyle(.segmented)
                    .padding()
                    .accessibilityLabel("Sort Tasks")
                    .accessibilityAddTraits(.isStaticText)
                    .focusable()
                     .onChange(of: viewModel.sortOption) { newSort in
                        viewModel.changeSortOption(newSort)
                    }

                    // Filtering Picker
                    Picker("Filter by", selection: $viewModel.filterStatus) {
                        ForEach(TaskStatus.allCases, id: \.self) { status in
                            Text(status.rawValue).tag(status).accessibilityLabel(status.rawValue).accessibilityAddTraits(.isSelected)
                                .accessibilityHint("Filter tasks by All, Completed, or Pending")

                        }
                    }
                    .pickerStyle(.segmented)
                    .padding()
                    .accessibilityLabel("Filter Tasks")
                    .accessibilityAddTraits(.isStaticText)
                    .focusable()
                    .onChange(of: viewModel.filterStatus) { newFilter in
                        viewModel.changeFilterStatus(newFilter)
                    }
                    List {
                        ForEach(viewModel.tasks, id: \.self) { task in
                            NavigationLink(destination: TaskDetailsView(task: task, viewModel: viewModel)) {
                                TaskRowView(task: task)
                            }
                        }
                        .onDelete { indexSet in
                            for index in indexSet {
                                viewModel.deleteTask(task: viewModel.tasks[index])
                            }
                        }
                    }.accessibilityLabel("List Of All Tasks")
                        .accessibilityAddTraits(.isStaticText)
                        .accessibilityHint("Swipe left to delete tasks")
                        .accessibilityElement(children: .combine)
                }
            }
            .navigationTitle("Tasks")
            .accessibilityLabel("Navigation Title is Tasks")
            .accessibilityAddTraits(.isHeader)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button(action: { showAddTask = true }) {
                        Text("Add Task")
                            .accessibilityLabel("Add Task Button")
                            .accessibilityHint("Opens the task creation screen")
                            .accessibilityAddTraits(.isButton)
                    }
                }
                ToolbarItem(placement: .topBarLeading) {
                                NavigationLink(destination: SettingsView()) {
                                    Image(systemName: "gearshape.fill").foregroundColor(accentColorVM.getSelectedColor())
                                }
                                .accessibilityLabel("Settings")
                                .accessibilityHint("Opens the settings screen")
                                .accessibilityAddTraits(.isButton)
                            }
            }
            .sheet(isPresented: $showAddTask) {
                TaskCreationView(viewModel: viewModel)
            }
        }
    }
}

#Preview {
    TaskListView()
}
