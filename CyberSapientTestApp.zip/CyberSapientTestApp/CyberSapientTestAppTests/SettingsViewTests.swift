//
//  SettingsViewTests.swift
//  CyberSapientTestAppTests
//
//  Created by vennela atcha on 2/27/25.
//

import XCTest
@testable import CyberSapientTestApp

final class SettingsViewTests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        // Any test you write for XCTest can be annotated as throws and async.
        // Mark your test throws to produce an unexpected failure when your test encounters an uncaught error.
        // Mark your test async to allow awaiting for asynchronous code to complete. Check the results with assertions afterwards.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
    func testDarkModeToggle() {
            let settings = UserDefaults.standard
            
            // Set Dark Mode ON
            settings.set(true, forKey: "isDarkMode")
            XCTAssertTrue(settings.bool(forKey: "isDarkMode"), "Dark mode should be enabled")
            
            // Set Dark Mode OFF
            settings.set(false, forKey: "isDarkMode")
            XCTAssertFalse(settings.bool(forKey: "isDarkMode"), "Dark mode should be disabled")
        }
        
        func testNotificationToggle() {
            let settings = UserDefaults.standard
            
            // Enable Notifications
            settings.set(true, forKey: "enableNotifications")
            XCTAssertTrue(settings.bool(forKey: "enableNotifications"), "Notifications should be enabled")
            
            // Disable Notifications
            settings.set(false, forKey: "enableNotifications")
            XCTAssertFalse(settings.bool(forKey: "enableNotifications"), "Notifications should be disabled")
        }
        
        func testAccentColorSelection() {
            let accentColorViewModel = AccentColorViewModel()
            let newColor = "red"
            
            // Change Accent Color
            accentColorViewModel.selectedColor = newColor
            
            XCTAssertEqual(accentColorViewModel.selectedColor, newColor, "Accent color should be updated correctly")
        }
        
        func testTextSizeAdjustment() {
            var textSize: Double = 14.0
            
            // Adjust Text Size
            textSize = 18.0
            
            XCTAssertEqual(textSize, 18.0, "Text size should be updated correctly")
        }
}
