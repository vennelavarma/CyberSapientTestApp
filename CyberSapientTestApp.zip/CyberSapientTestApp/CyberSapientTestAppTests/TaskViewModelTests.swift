//
//  TaskViewModelTests.swift
//  CyberSapientTestAppTests
//
//  Created by vennela atcha on 2/27/25.
//

import XCTest
import CoreData
import SwiftUI
@testable import CyberSapientTestApp

final class TaskViewModelTests: XCTestCase {

    var viewModel: TaskViewModel!
    var mockTask: Item!
    var managedObjectContext: NSManagedObjectContext!
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        // Initialize ViewModel and Mock Data
        viewModel = TaskViewModel()
       
        // Create an in-memory Core Data stack
        let container = NSPersistentContainer(name: "CyberSapientTestApp")
        let description = NSPersistentStoreDescription()
        description.type = NSInMemoryStoreType
        container.persistentStoreDescriptions = [description]
        
        let expectation = XCTestExpectation(description: "Load persistent stores")
        container.loadPersistentStores { _, error in
            XCTAssertNil(error, "Error loading in-memory store: \(error?.localizedDescription ?? "unknown error")")
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 5)
        
        managedObjectContext = container.viewContext
        mockTask = Item(context: managedObjectContext)
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        viewModel = nil
        mockTask = nil
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        // Any test you write for XCTest can be annotated as throws and async.
        // Mark your test throws to produce an unexpected failure when your test encounters an uncaught error.
        // Mark your test async to allow awaiting for asynchronous code to complete. Check the results with assertions afterwards.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
    // Test Save Context Functionality
      func testSaveContext() {
          // Set task status to completed
          mockTask.isTaskCompleted = true
          
          // Save context
          viewModel.saveContext()
          
          // Check if the context is saved properly (depending on your implementation)
          // You could verify the data was updated in Core Data, or check that saveContext is called
          // in your view model, depending on your approach.
          XCTAssertTrue(mockTask.isTaskCompleted, "Task should be marked as completed")
      }

}
