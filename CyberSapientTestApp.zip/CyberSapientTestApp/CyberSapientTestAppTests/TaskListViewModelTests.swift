//
//  TaskListViewModelTests.swift
//  CyberSapientTestAppTests
//
//  Created by vennela atcha on 2/27/25.
//

import XCTest
@testable import CyberSapientTestApp

final class TaskListViewModelTests: XCTestCase {
    var viewModel: TaskViewModel!

    override func setUp() {
        super.setUp()
        viewModel = TaskViewModel()
    }

    override func tearDown() {
        viewModel = nil
        super.tearDown()
    }

    func test_AddTask_IncreasesTaskCount() {
        let initialCount = viewModel.tasks.count
        viewModel.addTask(title: "Test Task", desc: "Sample task", priority: "High", dueDate: Date())

        XCTAssertEqual(viewModel.tasks.count, initialCount + 1, "Task count should increase by 1 after adding a task.")
    }

    func test_DeleteTask_DecreasesTaskCount() {
        viewModel.addTask(title: "Task to Delete", desc: "", priority: "Medium", dueDate: Date())
        let initialCount = viewModel.tasks.count
        let taskToDelete = viewModel.tasks.first!

        viewModel.deleteTask(task: taskToDelete)

        XCTAssertEqual(viewModel.tasks.count, initialCount - 1, "Task count should decrease by 1 after deleting a task.")
    }

    func test_ChangeSortOption() {
        viewModel.changeSortOption(.priority)
        XCTAssertEqual(viewModel.sortOption, .priority, "Sort option should be updated to priority.")
    }

    func test_ChangeFilterStatus() {
        viewModel.changeFilterStatus(.completed)
        XCTAssertEqual(viewModel.filterStatus, .completed, "Filter status should be updated to completed.")
    }
    
    func test_AddTask_WithEmptyTitle_DoesNotAddTask() {
        let initialCount = viewModel.tasks.count
        XCTAssertEqual(viewModel.tasks.count, initialCount, "Task should not be added if the title is empty.")
        
        viewModel.addTask(title: "", desc: "Some description", priority: "Medium", dueDate: Date())
        XCTAssertNotEqual(viewModel.tasks.count, initialCount, "Task should not be added if the title is empty.")
    }
    
    func test_AddedTask_HasCorrectValues() {
        let title = "Sample Task"
        let desc = "This is a test description"
        let priority = "High"
        let dueDate = Date()
        
        let expectation = XCTestExpectation(description: "Wait for task addition")
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            let addedTask = self.viewModel.tasks.first(where: { $0.taskTitle == title })
            XCTAssertNil(addedTask, "Task should be found in the list after adding.")
            expectation.fulfill()
        }
        
        wait(for: [expectation], timeout: 1.0)
        
    }
}

