//
//  TaskRowViewTests.swift
//  CyberSapientTestAppTests
//
//  Created by vennela atcha on 2/27/25.
//

import XCTest
import CoreData
import SwiftUI
@testable import CyberSapientTestApp

final class TaskRowViewTests: XCTestCase {
    
    var managedObjectContext: NSManagedObjectContext!
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        // Create an in-memory Core Data stack
        let container = NSPersistentContainer(name: "CyberSapientTestApp")
        let description = NSPersistentStoreDescription()
        description.type = NSInMemoryStoreType
        container.persistentStoreDescriptions = [description]
        
        let expectation = XCTestExpectation(description: "Load persistent stores")
        container.loadPersistentStores { _, error in
            XCTAssertNil(error, "Error loading in-memory store: \(error?.localizedDescription ?? "unknown error")")
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 5)
        
        managedObjectContext = container.viewContext
    }
    
    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        
        managedObjectContext = nil
    }
    
    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        // Any test you write for XCTest can be annotated as throws and async.
        // Mark your test throws to produce an unexpected failure when your test encounters an uncaught error.
        // Mark your test async to allow awaiting for asynchronous code to complete. Check the results with assertions afterwards.
    }
    
    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
    func testPriorityColor() {
        let highPriorityColor = TaskRowView(task: Item()).priorityColor(priority: "High")
        let mediumPriorityColor = TaskRowView(task: Item()).priorityColor(priority: "Medium")
        let lowPriorityColor = TaskRowView(task: Item()).priorityColor(priority: "Low")
        
        XCTAssertEqual(highPriorityColor, .red, "High priority should be red")
        XCTAssertEqual(mediumPriorityColor, .orange, "Medium priority should be orange")
        XCTAssertEqual(lowPriorityColor, .green, "Low priority should be green")
    }
    
    func createTestItem(isCompleted: Bool) -> Item {
        let task = Item(context: managedObjectContext)
        task.taskTitle = "Test Task"
        task.taskPriority = "High"
        task.dueDate = Date()
        task.isTaskCompleted = isCompleted
        return task
    }
    
    func testTaskCompletionIcon() {
        let completedTask = createTestItem(isCompleted: true)
        let pendingTask = createTestItem(isCompleted: false)
        
        let completedRowView = TaskRowView(task: completedTask)
        let pendingRowView = TaskRowView(task: pendingTask)
        
        XCTAssertNotNil(completedRowView.body, "Completed task should show a checkmark icon")
        XCTAssertNotNil(pendingRowView.body, "Pending task should show an empty circle icon")
    }
    
    func testTaskTitleAccessibility() {
        let task = Item(context: managedObjectContext)
        task.taskTitle = "Test Task"
        
        let rowView = TaskRowView(task: task)
        
        XCTAssertNotNil(rowView.body, "TaskRowView body should not be nil")
    }
    
    func testIsTaskCompletionIcon() {
        let completedTask = Item(context: managedObjectContext)
        completedTask.isTaskCompleted = true
        
        let pendingTask = Item(context: managedObjectContext)
        pendingTask.isTaskCompleted = false
        
        let completedRowView = TaskRowView(task: completedTask)
        let pendingRowView = TaskRowView(task: pendingTask)
        
        XCTAssertNotNil(completedRowView.body, "Completed task should show a checkmark icon")
        XCTAssertNotNil(pendingRowView.body, "Pending task should show an empty circle icon")
    }
}
